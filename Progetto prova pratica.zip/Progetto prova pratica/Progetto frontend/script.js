document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');

    // Fetch tasks from the API and display them
    function fetchTasks() {
        fetch('http://localhost/api/tasks')
            .then(response => response.json())
            .then(tasks => {
                taskList.innerHTML = '';
                tasks.forEach(task => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                        <span>${task.title}: ${task.description}</span>
                        <div>
                            <button class="btn-edit" data-id="${task.id}">Edit</button>
                            <button class="btn-delete" data-id="${task.id}">Delete</button>
                        </div>
                    `;
                    taskList.appendChild(li);
                });
            });
    }

    // Add a new task
    taskForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('task-title').value;
        const description = document.getElementById('task-description').value;

        fetch('http://localhost/api/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, description })
        })
        .then(response => response.json())
        .then(task => {
            fetchTasks();
            taskForm.reset();
        });
    });

    // Delete a task
    taskList.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-delete')) {
            const id = e.target.getAttribute('data-id');
            fetch(`http://localhost/api/tasks/${id}`, {
                method: 'DELETE'
            })
            .then(() => fetchTasks());
        }
    });

    fetchTasks();
});


